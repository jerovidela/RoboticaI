%% TP5B · Ejercicio 1 · Puntos 5, 6 y 7
% - Punto 5: 4 soluciones (theta1, theta2, theta3) para colocar la muñeca en c
% - Punto 6: Robot DH con longitudes unitarias (SerialLink)
% - Punto 7: Verificación por cinemática directa e inversa (consistencia de la muñeca)
%
% Estilo: funciones utilitarias (wrapToPi, clamp), trigonometría limpia,
% y algo de RTB si lo tenés instalado. Si no, igual corre el núcleo del Ej. 1.

%% ---------------- Demo del Punto 7 ----------------
% Configuración articular propuesta en grados [deg °]

q_deg = [30, -40, 50, 10, -20, 35];
q = deg2rad(q_deg);

% DH unitaria que usaremos para TODO (coherente con el punto 6)

%         [ theta   d      a      alpha ]
DH = [ ...
           0      0.000  0.000   +pi/2 ;   % 1
           0      0.000  1.000    0    ;   % 2
           0      0.000  1.000    0    ;   % 3
           0      0.000  0.000   +pi/2 ;   % 4
           0      0.000  0.000   -pi/2 ;   % 5
           0      1.000  0.000    0    ];  % 6   (d6=1)


% --- Punto 6: construir el SerialLink (si está RTB)

robot = SerialLink(DH, 'name', 'RobotUnitario');

% FK para conseguir T06 y la posición del extremo
if ~isempty(robot)
    T06 = robot.fkine(q).T;      % RTB (SE3 -> matriz 4x4)
else
    % FK “manual” mínima (solo necesitamos R06 y p06 para el punto 7)
    T06 = fkine6_min(dh, q);
end

% Si ya tenés T06
R06 = T06(1:3,1:3);
p06 = T06(1:3,4);

% Centro de muñeca (c0 = p06 - d6 * z6)
z6  = R06(:,3);
d6  = DH(6,2);
c0  = p06 - d6*z6;


% --- Punto 5: resolver las 4 soluciones de (th1, th2, th3) para colocar la muñeca en c
[Q4, info] = pieper1_solve4(c0, DH);

fprintf('\n--- Punto 5: Soluciones (theta1, theta2, theta3) ---\n');
for k = 1:size(Q4,2)
    fprintf('sol %d: [%+.6f  %+.6f  %+.6f] rad\n', k, Q4(1,k), Q4(2,k), Q4(3,k));
end

% --- Punto 7: verificar que TODAS las soluciones dan la misma muñeca c
fprintf('\n--- Punto 7: Verificación muñeca ---\n');
ok_same = true;
for k = 1:size(Q4,2)
    % Recalculo c desde (theta1..3) con el mismo DH unitarizado
    c_chk = wrist_from_123(Q4(:,k), DH);
    err   = norm(c_chk - c0);
    fprintf('sol %d -> ||c_calc - c0|| = %.3e\n', k, err);
    ok_same = ok_same && (err < 1e-9);
end
if ok_same
    fprintf('Todas las soluciones llevan a la MISMA muñeca (como corresponde).\n');
else
    fprintf('Ojo: hay soluciones que NO devuelven la misma muñeca (revisar DH o medidas).\n');
end

% Y una de las soluciones debería coincidir con los primeros 3 de q (salvo wrap)
dists = angle_dist_matrix(Q4, q(1:3));
[besterr, idxbest] = min(dists);
fprintf('\nSol más cercana a q(1:3) propuesto: sol %d  (error ang total = %.3e rad)\n', idxbest, besterr);

%% ===================== FUNCIONES PRINCIPALES =====================

function [Q4, info] = pieper1_solve4(c0, DH)
% pieper1_solve4  (Punto 5)
% Devuelve las 4 combinaciones de (th1, th2, th3) que ubican la muñeca en c0.
% Planteo: desacople, giro por th1 para llevar el problema al plano {1}, y 2R en x1-y1.
%
% dh: struct con alpha(1..6), a(1..6), d(1..6). Usamos 1..3 y d6.
%
% Salida:
%   Q4  : 3x4 con [th1; th2; th3] de las 4 ramas
%   info: struct con datos intermedios (por si querés depurar)

    a1 = DH(1, 3);   d1 = DH(1, 2);   al1 = DH(1, 4);
    a2 = DH(2, 3);   a3 = DH(3, 3);
    d3 = DH(3, 2);

    % 1) th1 tiene 2 candidatos
    th1a = atan2(c0(2), c0(1));
    th1b = wrapToPi(th1a + pi);

    % 2) Para cada th1, llevo c0 al marco {1}
    p1a = invTtransf(th1a, a1, d1, al1) * [c0; 1];
    p1b = invTtransf(th1b, a1, d1, al1) * [c0; 1];

    % Tomo el plano x1-y1 (primer problema de Pieper)
    r1a = hypot(p1a(1), p1a(2));
    r1b = hypot(p1b(1), p1b(2));

    % Longitud efectiva del 3er “eslabón” en el plano: si tu robot tiene offset en d3,
    % esta definición lo contempla. Si d3=0, queda en a3.
    L2 = a2;
    L3 = hypot(a3, d3);

    % 3) Ley del coseno: cos th3 = (r^2 - L2^2 - L3^2)/(2 L2 L3)
    c3a = clamp((r1a^2 - L2^2 - L3^2)/(2*L2*L3), -1, 1);
    c3b = clamp((r1b^2 - L2^2 - L3^2)/(2*L2*L3), -1, 1);

    th3a_up  =  acos(c3a);   th3a_dn = -acos(c3a);
    th3b_up  =  acos(c3b);   th3b_dn = -acos(c3b);

    % 4) th2 por trig. estándar de 2R en el plano
    phi_a = atan2(p1a(2), p1a(1));
    phi_b = atan2(p1b(2), p1b(1));

    th2a_up = wrapToPi(phi_a - atan2(L3*sin(th3a_up), L2 + L3*cos(th3a_up)));
    th2a_dn = wrapToPi(phi_a - atan2(L3*sin(th3a_dn), L2 + L3*cos(th3a_dn)));
    th2b_up = wrapToPi(phi_b - atan2(L3*sin(th3b_up), L2 + L3*cos(th3b_up)));
    th2b_dn = wrapToPi(phi_b - atan2(L3*sin(th3b_dn), L2 + L3*cos(th3b_dn)));

    Q4 = [ ...
        wrapToPi([th1a; th2a_up; th3a_up]), ...
        wrapToPi([th1a; th2a_dn; th3a_dn]), ...
        wrapToPi([th1b; th2b_up; th3b_up]), ...
        wrapToPi([th1b; th2b_dn; th3b_dn]) ];

    info = struct('p1a',p1a,'p1b',p1b,'L2',L2,'L3',L3,'r1a',r1a,'r1b',r1b);
end


function T06 = fkine6_min(dh, q)
% fkine6_min  FK mínima para no depender de RTB
    T06 = eye(4);
    for i = 1:6
        T06 = T06 * MCambioDeBase(q(i), dh.d(i), dh.a(i), dh.alpha(i));
    end
end

function c = wrist_from_123(q123, DH)
% wrist_from_123  Reconstruye c usando solo {1..3} y el plano x1-y1 del método geométrico.
% (coincide con el planteo del punto 5)
    a1 = DH(1, 3);   d1 = DH(1, 2);   al1 = DH(1, 4);
    a2 = DH(2, 3);   a3 = DH(3, 3);
    d3 = DH(3, 2);


    L2 = a2; L3 = hypot(a3, d3);

    th1 = q123(1); th2 = q123(2); th3 = q123(3);

    p1 = [ ...
        L2*cos(th2) + L3*cos(th2+th3);
        L2*sin(th2) + L3*sin(th2+th3);
        0; 1];

    T01 = MCambioDeBase(th1, d1, a1, al1);
    c   = (T01 * p1);
    c   = c(1:3);
end

%% ===================== UTILIDADES =====================

function A = MCambioDeBase(theta, d, a, alpha)
    c = cos(theta); s = sin(theta);
    ca = cos(alpha); sa = sin(alpha);
    A = [ c, -s*ca,  s*sa, a*c;
          s,  c*ca, -c*sa, a*s;
          0,    sa,    ca,   d;
          0,     0,     0,   1 ];
end

function Tinv = invTtransf(th1, a1, d1, al1)
% Inversa de 0T1 = Rz(th1)Tz(d1)Tx(a1)Rx(al1)
    T01  = MCambioDeBase(th1, d1, a1, al1);
    R    = T01(1:3,1:3); t = T01(1:3,4);
    Tinv = [R.', -R.'*t; 0 0 0 1];
end

function y = clamp(x, lo, hi)
    y = min(max(x, lo), hi);
end

function ang = wrapToPi(ang)
    ang = mod(ang + pi, 2*pi) - pi;
end

function D = angle_dist_matrix(Q4, qref)
% suma de errores absolutos, con wrap
    D = zeros(1,size(Q4,2));
    for k = 1:size(Q4,2)
        e = wrapToPi(Q4(:,k) - qref(:));
        D(k) = sum(abs(e));
    end
end
